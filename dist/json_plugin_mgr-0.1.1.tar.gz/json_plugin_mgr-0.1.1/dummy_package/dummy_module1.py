
def entry_point1():
    """
    A dummy entry point to test the Plugin Manager

    :return: None

    """
    pass


def entry_point2():
    """
    A dummy entry point to test the Plugin Manager

    :return: None

    """
    pass
