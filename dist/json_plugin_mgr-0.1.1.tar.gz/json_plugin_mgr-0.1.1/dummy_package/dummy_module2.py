def entry_point_3():
    """
    A dummy entry point to test the Plugin Manager

    :return: None

    """
    pass


def entry_point_4():
    """
    A dummy entry point to test the Plugin Manager

    :return: None

    """
    pass
