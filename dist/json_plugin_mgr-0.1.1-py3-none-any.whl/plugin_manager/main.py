# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

import plugin_manager.gui.tk_gui as gui


def launch():
    app = gui.Application()
    app.mainloop()


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    launch()
# See PyCharm help at https://www.jetbrains.com/help/pycharm/
